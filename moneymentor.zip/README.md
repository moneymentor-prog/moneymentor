# 🐻‍❄️ MoneyMentor

> **Small Steps, Bigger Wealth.**

A unique 8-bit retro-styled personal financial planning dashboard that helps users build customized goal-based investment plans. Built with pure HTML, CSS, and JavaScript — no frameworks, no build step, ready to publish.

---

## ✨ Features

### Onboarding Flow (5 Steps)
1. **Profile** — Name, age, city, marital status, employment
2. **Income** — Salary, rental, interest, other income
3. **Expenses** — Home, grocery, fuel, education, EMI, insurance, lifestyle
4. **Goals** — Select & prioritize financial goals (retirement, education, emergency fund, etc.)
5. **Risk Profile** — Risk tolerance, existing investments, experience level

### Dashboard Sections
| Section | What It Shows |
|---------|--------------|
| **DIA** | Personalized advisor introduction with your data |
| **Cash Flow** | Income vs expenses visualization, surplus calculation |
| **Financial Health** | Reserve Surplus, Saving-to-Surplus, Debt-to-Income ratios |
| **Rule-Based Analysis** | 50-30-20 rule, 6x emergency fund, 10x insurance, retirement corpus |
| **Beliefs** | Risk-reward philosophy alignment |
| **Goals** | Goal-based planning with SIP calculators, scenario analysis |
| **Investments** | Portfolio overview, asset allocation charts, holdings table |
| **Actionable** | Execute SIPs, track goal events, view history |

### Calculations & Rules Applied
- **Reserve Surplus Ratio** — Surplus ÷ Income (target: >25%)
- **Saving-to-Surplus Ratio** — SIP ÷ Surplus (target: >75%)
- **Debt-to-Income Ratio** — EMI ÷ Income (target: <20%)
- **50-30-20 Rule** — Needs/Wants/Savings breakdown
- **6x Emergency Fund** — 6 months of expenses
- **10x Insurance Cover** — 10x annual income
- **Retirement Corpus** — Inflation-adjusted expense × post-retire years × 0.7
- **SIP Calculator** — Future value of monthly investments
- **Scenario Analysis** — Bull/Base/Bear case projections

### Design
- 🎮 8-bit pixel art aesthetic (Press Start 2P font)
- 🐻‍❄️ Custom polar bear logo
- 🌲 Dark green forest theme
- 📺 CRT scanline effect
- ✨ Pixel grid background
- 📊 Interactive Chart.js charts
- 🎯 Animated progress indicators

---

## 🚀 How to Publish (3 Free Options)

### Option 1: GitHub Pages (Recommended — Free & Permanent)

1. **Create a GitHub account** at [github.com](https://github.com) (if you don't have one)

2. **Create a new repository**
   - Click "+" → "New repository"
   - Name: `moneymentor` (or any name)
   - Make it **Public**
   - Check "Add a README file" (optional)
   - Click "Create repository"

3. **Upload files**
   - Click "Add file" → "Upload files"
   - Drag & drop these files:
     - `index.html`
     - `images/polar-bear-logo.png`
   - Click "Commit changes"

4. **Enable GitHub Pages**
   - Go to **Settings** → **Pages** (left sidebar)
   - Under "Source", select **Deploy from a branch**
   - Select branch: `main`, folder: `/ (root)`
   - Click "Save"

5. **Wait 1-2 minutes**, then visit:
   ```
   https://yourusername.github.io/moneymentor
   ```
   *(Replace `yourusername` with your actual GitHub username)*

---

### Option 2: Netlify Drop (Easiest — Drag & Drop)

1. Go to [netlify.com](https://netlify.com) and sign up (free)

2. Go to [app.netlify.com/drop](https://app.netlify.com/drop)

3. **Drag & drop** the entire `moneymentor` folder onto the page

4. Netlify instantly gives you a live URL like:
   ```
   https://moneymentor-abc123.netlify.app
   ```

5. **Optional**: Go to Site settings → Domain management → Add custom domain

---

### Option 3: Vercel (Fast & Free)

1. Go to [vercel.com](https://vercel.com) and sign up with GitHub

2. Click "Add New..." → "Project"

3. **Import** your GitHub repository (if you used Option 1)

4. Or use Vercel CLI:
   ```bash
   npm i -g vercel
   cd moneymentor
   vercel
   ```

5. Your site goes live instantly at:
   ```
   https://moneymentor-yourname.vercel.app
   ```

---

## 🛠️ Customization

### Change Colors
Edit the `:root` CSS variables in `index.html`:
```css
:root {
    --bg-dark: #0d1f0d;        /* Main background */
    --bg-card: #1a3a1a;        /* Card background */
    --accent-green: #2d8a2d;   /* Primary green */
    --accent-bright: #4ade4a;  /* Bright green */
    --accent-cyan: #00e5c9;    /* Cyan accent */
    --accent-pink: #ff6b9d;    /* Pink/warning */
    --accent-yellow: #f0e040;  /* Yellow highlight */
}
```

### Change Default User Data
Look for the `value=` attributes in the onboarding form inputs:
```html
<input type="text" id="ob-name" value="Vibhuti">
<input type="number" id="ob-age" value="30">
```

### Change Logo
Replace `images/polar-bear-logo.png` with your own image (keep the same filename or update the `src` in HTML).

### Add More Goals
In the JavaScript `goalMap` object, add new goals:
```javascript
const goalMap = {
    emergency: { name: 'Emergency Fund', icon: '🛡️' },
    retirement: { name: 'Retirement', icon: '🗺️' },
    // Add your custom goal here
    startup: { name: 'Startup Fund', icon: '🚀' }
};
```

---

## 📁 File Structure

```
moneymentor/
├── index.html              # Main application (all HTML, CSS, JS)
├── images/
│   └── polar-bear-logo.png # Your logo
└── README.md               # This file
```

**No build step required!** It's a single HTML file with embedded CSS and JavaScript.

---

## 🔧 Tech Stack

| Technology | Purpose |
|-----------|---------|
| HTML5 | Structure |
| CSS3 | 8-bit styling, animations, responsive grid |
| Vanilla JavaScript | All logic, calculations, interactivity |
| Chart.js 4.4.1 | Interactive charts (loaded from CDN) |
| Press Start 2P | 8-bit pixel font (Google Fonts) |

---

## 📱 Browser Support

- ✅ Chrome / Edge (recommended)
- ✅ Firefox
- ✅ Safari
- ✅ Mobile browsers (responsive design)

---

## 📝 License

MIT License — free to use, modify, and publish.

---

**Built with 💚 and pixels.**
